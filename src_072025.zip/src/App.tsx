// App.tsx
import React, { useState } from "react";
import { GameCanvas } from "./components/GameCanvas";
import { TrackEditor } from "./components/TrackEditor";
import { GamePlay } from "./components/GamePlay";

function App() {
  const [size, setSize] = useState(600);
  const [mode, setMode] = useState<"play" | "edit">("play");
  const [resetCounter, setResetCounter] = useState(0);

  const handleSizeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSize(parseInt(e.target.value));
    setResetCounter((prev) => prev + 1); // trigger reset
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">Racetrack Game</h1>

      <div className="flex gap-4 mb-4">
        {/* Only show this in edit mode */}
        {mode === "edit" && (
          <div>
            <label className="mr-2">Select size:</label>
            <select
              className="p-2 border rounded"
              value={size}
              onChange={handleSizeChange}
            >
              <option value={400}>Small (400x400)</option>
              <option value={600}>Medium (600x600)</option>
              <option value={900}>Large (900x900)</option>
              <option value={1200}>Huge (1200x1200)</option>
            </select>
          </div>
        )}

        <div>
          <label className="mr-2">Mode:</label>
          <button
            className={`p-2 rounded border ${mode === "play" ? "bg-blue-500 text-white" : "bg-white"}`}
            onClick={() => setMode("play")}
          >
            Play
          </button>
          <button
            className={`p-2 rounded border ml-2 ${mode === "edit" ? "bg-green-500 text-white" : "bg-white"}`}
            onClick={() => setMode("edit")}
          >
            Edit
          </button>
        </div>
      </div>

      {mode === "play" ? (
        <GamePlay size={size} />
      ) : (
        <TrackEditor size={size} resetSignal={resetCounter} />
      )}
    </div>
  );

}

export default App;
