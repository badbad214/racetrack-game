interface GlobalGridOverlayProps {
  spacing: number;
  tileSize: number;
  x: number;
  y: number;
  cols: number;
  rows: number;
  occupiedTiles: Set<string>;

}

export const GlobalGridOverlay: React.FC<GlobalGridOverlayProps> = ({
  spacing,
  tileSize,
  x,
  y,
  cols,
  rows,
  occupiedTiles, // ✅ correctly destructured here
}) => {
  const width = cols * tileSize;
  const height = rows * tileSize;
  const lines = [];

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const tileX = x + col;
      const tileY = y + row;
      const key = `${tileX},${tileY}`;
      if (!occupiedTiles.has(key)) continue;

      const offsetX = col * tileSize;
      const offsetY = row * tileSize;

      for (let i = 0; i <= tileSize; i += spacing) {
        // Vertical line inside the tile
        lines.push(
          <line
            key={`v-${key}-${i}`}
            x1={offsetX + i + 0.5}
            y1={offsetY}
            x2={offsetX + i + 0.5}
            y2={offsetY + tileSize}
            stroke="white"
            strokeWidth="1"
          />
        );
        // Horizontal line inside the tile
        lines.push(
          <line
            key={`h-${key}-${i}`}
            x1={offsetX}
            y1={offsetY + i + 0.5}
            x2={offsetX + tileSize}
            y2={offsetY + i + 0.5}
            stroke="white"
            strokeWidth="1"
          />
        );
      }
    }
  }
  return (
    <svg
      width={width}
      height={height}
      style={{
        position: "absolute",
        top: y * tileSize,
        left: x * tileSize,
        pointerEvents: "none",
        zIndex: 5,
      }}
      shapeRendering="crispEdges"
    >
      {lines}
    </svg>
  );
};
