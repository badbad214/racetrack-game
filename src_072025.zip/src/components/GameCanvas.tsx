// Component: src/components/GameCanvas.tsx

import React, { useEffect, useRef, useState } from "react";

interface GameCanvasProps {
  size: number;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ size }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [position, setPosition] = useState({ x: 5, y: 5 });
  const [velocity, setVelocity] = useState({ x: 0, y: 0 });

  const gridSize = 20; // Each cell is 20x20 pixels
  const width = size;
  const height = size;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw grid
    ctx.strokeStyle = "#ddd";
    for (let x = 0; x <= width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y <= height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw player
    ctx.fillStyle = "blue";
    ctx.fillRect(
      position.x * gridSize,
      position.y * gridSize,
      gridSize,
      gridSize
    );
  }, [position, width, height]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      let dx = 0, dy = 0;
      if (e.key === "ArrowUp") dy = -1;
      if (e.key === "ArrowDown") dy = 1;
      if (e.key === "ArrowLeft") dx = -1;
      if (e.key === "ArrowRight") dx = 1;

      const newVelocity = {
        x: velocity.x + dx,
        y: velocity.y + dy
      };

      const newPosition = {
        x: position.x + newVelocity.x,
        y: position.y + newVelocity.y
      };

      setVelocity(newVelocity);
      setPosition(newPosition);
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [velocity, position]);

  return <canvas ref={canvasRef} width={width} height={height} className="border" />;
};