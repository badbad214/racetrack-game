import React, { useState, useRef } from "react";
import { GlobalGridOverlay } from "./GlobalGridOverlay";

// Track section types
type SectionType = "start" | "straight" | "curve90";

interface Section {
    id: string;
    type: SectionType;
    x: number;
    y: number;
    rotation: number;
}

interface GamePlayProps {
    size: number;
}

export const GamePlay: React.FC<GamePlayProps> = ({ size }) => {
    const [sections, setSections] = useState<Section[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [raceStarted, setRaceStarted] = useState(false);
    const [playerCount, setPlayerCount] = useState(2);
    const [playerControllers, setPlayerControllers] = useState<("AI" | "RL")[]>(["RL", "AI", "AI", "AI"]);

    const fileInputRef = useRef<HTMLInputElement>(null);

    const imageMap: Record<SectionType, string> = {
        start: "/tiles/start.png",
        straight: "/tiles/straight.png",
        curve90: "/tiles/curve.png",
    };

    const gridUnit = 100;
    const cols = Math.floor(size / gridUnit);
    const rows = Math.floor(size / gridUnit);

    function handleLoadClick(): void {
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    }

    function handleFileChange(event: React.ChangeEvent<HTMLInputElement>): void {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result as string;
                const parsed = JSON.parse(text);
                if (!Array.isArray(parsed)) throw new Error("File format invalid");

                for (const s of parsed) {
                    if (!["start", "straight", "curve90"].includes(s.type)) {
                        throw new Error(`Invalid section type: ${s.type}`);
                    }
                    if (typeof s.x !== "number" || typeof s.y !== "number") {
                        throw new Error("Invalid coordinates");
                    }
                }

                setSections(parsed);
                setError(null);
            } catch (err: any) {
                setError(err.message);
            }
        };
        reader.readAsText(file);
    }

    function getBoundingBox(sections: Section[]): { minX: number; minY: number; maxX: number; maxY: number } | null {
        if (sections.length === 0) return null;

        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (const s of sections) {
            minX = Math.min(minX, s.x);
            minY = Math.min(minY, s.y);
            maxX = Math.max(maxX, s.x);
            maxY = Math.max(maxY, s.y);
        }

        return { minX, minY, maxX, maxY };
    }

    const bbox = getBoundingBox(sections);
    const occupied = new Set(sections.map((s) => `${s.x},${s.y}`));

    return (
        <div className="flex flex-col items-center gap-4 w-full">
            <h2>Play Mode</h2>

            {/* Load & Clear Buttons */}
            {!raceStarted ? (
                <div style={{ display: "flex", gap: "8px", marginBottom: "8px" }}>
                    <button
                        onClick={handleLoadClick}
                        style={{
                            padding: "8px 16px",
                            backgroundColor: "#003399",
                            color: "#fff",
                            border: "none",
                            borderRadius: "4px",
                            cursor: "pointer",
                            fontWeight: "bold"
                        }}
                    >
                        📂 Load Track
                    </button>

                    <button
                        onClick={() => setSections([])}
                        style={{
                            padding: "8px 16px",
                            backgroundColor: "#cc0000",
                            color: "#fff",
                            border: "none",
                            borderRadius: "4px",
                            cursor: "pointer",
                            fontWeight: "bold"
                        }}
                    >
                        🧹 Clear Track
                    </button>
                </div>
            ) : (
                <div style={{ marginBottom: "8px" }}>
                    <button
                        onClick={() => {
                            setRaceStarted(false);
                            setPlayerCount(2);
                            setPlayerControllers(["RL", "AI", "AI", "AI"]);
                        }}
                        style={{
                            padding: "8px 16px",
                            backgroundColor: "#990000",
                            color: "#fff",
                            border: "none",
                            borderRadius: "4px",
                            cursor: "pointer",
                            fontWeight: "bold"
                        }}
                    >
                        ⛔ Cancel Race
                    </button>
                </div>
            )}


            <input ref={fileInputRef} type="file" accept=".json" style={{ display: "none" }} onChange={handleFileChange} />

            {/* Error Display */}
            {error && (
                <div style={{ color: "red", marginTop: "8px" }}>
                    <strong>Error:</strong> {error}
                </div>
            )}

            {/* Player Setup (before race starts) */}
            {!raceStarted && (
                <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginBottom: "16px" }}>
                    <div>
                        <label style={{ marginRight: "8px", fontWeight: "bold" }}>Players:</label>
                        <select
                            value={playerCount}
                            onChange={(e) => {
                                const count = parseInt(e.target.value);
                                setPlayerCount(count);
                                setPlayerControllers((prev) => {
                                    const updated = [...prev];
                                    while (updated.length < count) updated.push("AI");
                                    return updated.slice(0, count);
                                });
                            }}
                        >
                            <option value={2}>2</option>
                            <option value={3}>3</option>
                            <option value={4}>4</option>
                        </select>
                    </div>

                    {Array.from({ length: playerCount - 1 }, (_, i) => (
                        <div key={i + 1}>
                            <label style={{ marginRight: "8px" }}>Player {i + 2}:</label>
                            <button
                                onClick={() => {
                                    setPlayerControllers((prev) => {
                                        const updated = [...prev];
                                        updated[i + 1] = updated[i + 1] === "AI" ? "RL" : "AI";
                                        return updated;
                                    });
                                }}
                                style={{
                                    padding: "4px 12px",
                                    backgroundColor: playerControllers[i + 1] === "AI" ? "#999" : "#0a0",
                                    color: "#fff",
                                    border: "none",
                                    borderRadius: "4px",
                                    cursor: "pointer",
                                    fontWeight: "bold",
                                }}
                            >
                                {playerControllers[i + 1] === "AI" ? "🤖 AI" : "👤 RL"}
                            </button>
                        </div>
                    ))}

                    <button
                        onClick={() => setRaceStarted(true)}
                        style={{
                            padding: "8px 16px",
                            backgroundColor: "#007700",
                            color: "#fff",
                            border: "none",
                            borderRadius: "4px",
                            cursor: "pointer",
                            fontWeight: "bold",
                            marginTop: "12px",
                        }}
                    >
                        🚦 Start Race
                    </button>
                </div>
            )}

            {/* Grid & Tiles */}
            <div
                style={{
                    width: size,
                    height: size,
                    background: "#f0f0f0",
                    border: "2px dashed gray",
                    display: "grid",
                    gridTemplateColumns: `repeat(${cols}, ${gridUnit}px)`,
                    gridTemplateRows: `repeat(${rows}, ${gridUnit}px)`,
                    position: "relative",
                }}
            >
                {/* Grid cells */}
                {Array.from({ length: rows * cols }).map((_, i) => (
                    <div key={`cell-${i}`} style={{ border: "1px solid #ccc" }} />
                ))}

                {/* Track tiles */}
                {sections.map((section) => (
                    <div
                        key={section.id}
                        style={{
                            gridColumnStart: section.x + 1,
                            gridRowStart: section.y + 1,
                            position: "relative",
                            width: "100px",
                            height: "100px",
                            transform: `rotate(${section.rotation}deg)`,
                            transformOrigin: "center",
                            zIndex: 1,
                        }}
                    >
                        <img
                            src={imageMap[section.type]}
                            alt={section.type}
                            style={{
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                                pointerEvents: "none",
                            }}
                        />
                    </div>
                ))}

                {/* Grid overlay */}
                {bbox && (
                    <GlobalGridOverlay
                        spacing={15}
                        tileSize={gridUnit}
                        x={bbox.minX}
                        y={bbox.minY}
                        cols={bbox.maxX - bbox.minX + 1}
                        rows={bbox.maxY - bbox.minY + 1}
                        occupiedTiles={occupied}
                    />
                )}
            </div>
        </div>
    );
};
